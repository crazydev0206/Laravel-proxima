<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'profile_menu' => "Profile menu",
    'my_profile' => 'My profile',
    'personal_information' => 'Personal information',
    'photo' => 'Photo',
    'preferences' => 'Preferences',
    'vehicle' => 'Vehicle',
    'my_ratings' => "My ratings",
    'ratings_left' => "Ratings I left",
    'ratings_received' => "Ratings I received",
    'my_wallet' => "My wallet",
    'balance_transactions' => "Balance & Transactions",
    'payout' => "Payout",
    'my_cards' => "My cards",
    'my_account' => "My account",
    'home_address' => "Home address",
    'phone' => "Phone",
    'email' => "Email",
    'password' => "Password",
    'close_my_account' => "Close my account",
    'verifications' => "Verifications",
    'verify_phone_number' => "Verify phone number",
    'verify_driver_license' => "Verify driver's license",
    'verify_student_card' => "Verify student card",
    'indicates_required_fields' => "Indicates required fields",
    'to_be_eligible' => "(To be eligible for the “Pink rides” and “Extra-care rides”, you must enter you complete address)",
    'i_reviewed' => "I reviewed",
    'members' => "members",
    'reviewed_by' => "Reviewed by",
    'all_transactions' => "All transactions",
    '#id' => "#ID",
    'user' => "User",
    'transaction_details' => "Transactions details",
    'amount' => "Amount",
    'on_date' => "On date",
    'cad' => "CAD",
    'add_card' => "Add a card",
    'this_phone_number' => "This is your phone number",
    'update_phone_number' => "Update your phone number",
    'this_email_address' => "This is your email address",
    'update_email_address' => "Update your email address",

];
