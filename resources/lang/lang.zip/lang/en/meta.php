<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'keywords' => 'ProximaRide, Ridesharing',
    'description' => 'We are proud to be the first to introduce new rides types in North America.',

];
